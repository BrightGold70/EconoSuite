.EurostatEnv <- new.env()
