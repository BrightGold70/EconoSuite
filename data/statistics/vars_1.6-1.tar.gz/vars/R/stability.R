"stability" <-
function(x, ...){
  UseMethod("stability")
}

"stability.default" <-
    function(x, type = c("OLS-CUSUM", "Rec-CUSUM", "Rec-MOSUM", "OLS-MOSUM", "RE",
                         "ME", "Score-CUSUM", "Score-MOSUM", "fluctuation"),
             h = 0.15, dynamic = FALSE, rescale = TRUE, ...){
        strucchange::sctest(x, ...)
}

"stability.varest" <-
    function(x, type = c("OLS-CUSUM", "Rec-CUSUM", "Rec-MOSUM", "OLS-MOSUM", "RE",
                         "ME", "Score-CUSUM", "Score-MOSUM", "fluctuation"),
             h = 0.15, dynamic = FALSE, rescale = TRUE, ...){
  type <- match.arg(type)
  K <- x$K
  stability <- list()
  endog <- colnames(x$datamat)[1 : K]
  for(i in 1 : K){
    formula <- formula(x$varresult[[i]])
    data <- x$varresult[[i]]$model
    stability[[endog[i]]] <- efp(formula = formula, data = data, type = type, h = h, dynamic = dynamic, rescale = rescale)
  }
  result <- list(stability = stability, names = endog, K = K)
  class(result) <- "varstabil"
  return(result)
}
